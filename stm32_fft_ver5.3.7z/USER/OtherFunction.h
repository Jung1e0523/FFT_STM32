#ifndef __OTHERFUNCTION_H
#define __OTHERFUNCTION_H	

#include "sys.h"
void drawspectrum( u16 xend, u16 yend);
void drawspectrum_clear(u16 xend, u16 yend);

#endif
